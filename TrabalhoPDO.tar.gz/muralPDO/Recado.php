<?php

class Recado{
    public $id;
    public $nome;
    public $email;
    public $cidade;
    public $texto;
}